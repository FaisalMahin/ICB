import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;

public class ContractorCellRenderer extends ListCell<Contractor> {
    @Override
    protected void updateItem(Contractor contractor, boolean empty) {
        super.updateItem(contractor, empty);
        if (empty || contractor == null) {
            setText(null);
        } else {
            setText(contractor.toString());
        }
    }
}