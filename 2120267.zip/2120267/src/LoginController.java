import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {

    static String user;
    private String pass;
     
     
    
   @FXML
    private Button loginButton;
    
    @FXML
    private TextField username;

    @FXML
    private TextField password;

    @FXML
    void login(ActionEvent e) {

         user = username.getText();

         pass = password.getText();


        if (authenticate(user, pass)) {
             
         
                Stage stage = (Stage) loginButton.getScene().getWindow();
                stage.close();
                SwitchToUserProfile();
                 

        } else {

            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText("Invalid Credentials");
            alert.setContentText("Please enter a valid username and password.");
            alert.showAndWait();

        }

    }


    private boolean authenticate(String user, String pass) {

        if (user.equals("Dibyo") && pass.equals("123456")) {

            return true;

        }
        else
        return false;

    }

    public void SwitchToUserProfile(){
    
    try {  
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UserDeveloper.fxml"));
                Parent root = loader.load();
                UserDeveloperController userdevelopercontroller= loader.getController();
                userdevelopercontroller.info(user);
                
             
           
                Stage stage = new Stage();
                stage.setTitle("User Profile");
                stage.setScene(new Scene(root, 700, 400));
                

                stage.setResizable(false);
                
                stage.show();
                
            } 
            catch (IOException ex) {

                ex.printStackTrace();

            }
            
    
    }
    
    
    
    
   
    
    
}