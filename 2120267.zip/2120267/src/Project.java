

import java.util.ArrayList;
import java.util.List;

public class Project {
    private String location;
    private String size;
    private String details;
    private String compliance;
    private List<Contractor> contractors;

    
    

    public Project(String location, String size, String details,String compliance) {
        this.location = location;
         this.size = size;
        this.details = details;
        this.compliance=compliance;
        this.contractors = new ArrayList<>();
    }

  

    // Getters and setters

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getCompliance() {
        return compliance;
    }

    public void setCompliance(String compliance) {
        this.compliance = compliance;
    }
    
    

    public List<Contractor> getContractors() {
        return contractors;
    }

    public void setContractors(List<Contractor> contractors) {
        this.contractors = contractors;
    }
    
    @Override
    public String toString() {

        return "Project: (" + " Location: " + location + ", Project Size: " + size + " sq.ft)";
    }

}

