import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.stage.Stage;


public class PropertyController implements Initializable  {
    
     static String location;
     static String size;
     static String specification;
     static String compliance;
   static  ArrayList<Project> projectsArrayList=new ArrayList<>();
     private Alert alert;
    
     
    @FXML
    private Button btnSubmit;
    
    @FXML
    private Button btnBack;

    @FXML
    private ChoiceBox<String> locationChoiceBox;


    @FXML
    private TextField tfAreaSize;


    @FXML
    private TextField tfSpecification;


    @FXML
    private RadioButton rbReputated;


    @FXML
    private RadioButton rbBad;


    @FXML
    private RadioButton rbAverage;
    
   

    
    public String getLocation() {
        return location;
    }

    public String getSize() {
        return size;
    }


    public String getSpecification() {
        return specification;
    }
    
 public String getCompliance() {
        return compliance;
    }


    
   
   @FXML 
    void submit(ActionEvent e){
        location = locationChoiceBox.getValue();
        size= tfAreaSize.getText();
        specification= tfSpecification.getText();
        compliance = complianceStatus();
    

        System.out.println(location);
        System.out.println(size);
        System.out.println(specification);
        System.out.println(compliance);
     
          projectArray();
        alert = new Alert(Alert.AlertType.INFORMATION);

                    alert.setTitle("Successful");

                    alert.setContentText("Informations Saved Correctly");

                    alert.showAndWait();
                    
                    
       //projectcontrollerInitialize();
    }
    
  
    @FXML
    void PropertyBack(ActionEvent e) {

                Stage stage = (Stage) btnBack.getScene().getWindow();
                stage.close();
                SwitchToUserProfile();
         
                
        }
    
  
    
    String complianceStatus(){
      String status= null;
      if (rbReputated.isSelected() ) {

        status = rbReputated.getText();
     
    } else if (rbAverage.isSelected()) {

        status = rbAverage.getText();

    }
    else if(rbBad.isSelected()){
      status = rbBad.getText();
     
    }
      return status;  
    }
    
    
    
    
 void SwitchToUserProfile(){
    
    try {  
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UserDeveloper.fxml"));
                Parent root = loader.load();
              
                UserDeveloperController userdevelopercontroller= loader.getController();
                userdevelopercontroller.info(LoginController.user);
               
                Stage stage = new Stage();
                stage.setTitle("User Profile");
                stage.setScene(new Scene(root, 700, 400));
                stage.setResizable(false);
                
                stage.show();
                
            } 
            catch (IOException ex) {

                ex.printStackTrace();

            }
            
    
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
     locationChoiceBox.getItems().addAll("Dhanmondi", "Gulshan", "Banani", "Uttara", "Bashundhora");
     ToggleGroup toggleGroup = new ToggleGroup();
     toggleGroup.getToggles().addAll(rbReputated,rbAverage,rbBad);
    }
    

    
void projectArray(){
    
        
        Project project = new Project(location,size,specification,compliance);
        
        projectsArrayList.add(project);
   
    }

}
