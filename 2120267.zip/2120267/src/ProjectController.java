import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class ProjectController  {

    private String location;
    private String areasize; 
    private String Description;
    private String compliance;
    
    @FXML
    private Label lbprojectComplianace;

    @FXML
    private Label lbprojectDescription;

    @FXML
    private Label lbprojectLocation;

    @FXML
    private Label lbprojectSize;
        @FXML
    private Button btnProjectBack;


    public String getLocation() {
        return location;
    }

    public String getAreasize() {
        return areasize;
    }

    public String getDescription() {
        return Description;
    }

    public String getCompliance() {
        return compliance;
    }
    
    
    
    void infoTake(String location,String areasize, String Description,String compliance){
    
        
        
    this.location= location;
    this.areasize=  areasize;
    this.Description= Description;
    this.compliance= compliance;
    
    lbprojectLocation.setText(this.location);
    lbprojectSize.setText(this.areasize);
    lbprojectDescription.setText(this.Description);
    lbprojectComplianace.setText(this.compliance);
    // initialize() ;
    }
     
   @FXML
   void ProjectBack(ActionEvent e) {

                Stage stage = (Stage) btnProjectBack.getScene().getWindow();
                stage.close();
                SwitchToUserProfile();
    
        }
   
  void SwitchToUserProfile(){
    
    try {  
                FXMLLoader loader = new FXMLLoader(getClass().getResource("UserDeveloper.fxml"));
                Parent root = loader.load();
              
                UserDeveloperController userdevelopercontroller= loader.getController();
                userdevelopercontroller.info(LoginController.user);
               
                Stage stage = new Stage();
                stage.setTitle("User Profile");
                stage.setScene(new Scene(root, 700, 400));
                stage.setResizable(false);
                
                stage.show();
                
            } 
            catch (IOException ex) {

                ex.printStackTrace();

            }
   

}
  
  @FXML
    private ListView<Contractor> contractorsListView;

  public void initialize() {
         if(PropertyController.location  == null){
          
        } 
         else {
             
        Project project = new Project(this.location,this.areasize,this.Description,this.compliance);
        Contractor contractor1 = new Contractor("Humpty","123 Street" , project);
        Contractor contractor2 = new Contractor("Dumpty","456 Street", project);

        // Set the contractors for the project
        project.getContractors().add(contractor1);
        project.getContractors().add(contractor2);
       
        // Set the items for the ListView
        contractorsListView.setCellFactory(lv -> new ContractorCellRenderer());
        
        contractorsListView.getItems().add(contractor1);
        contractorsListView.getItems().add(contractor2);
       
    } 
   }
}