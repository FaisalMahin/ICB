import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

public class UserDeveloperController {
    
    
    @FXML
    private Label lbWelcome;
    
     @FXML
    private Label lbName;
     
     @FXML
    private Label lbEmail;
     
     @FXML
    private Label lbNodata;
     
    @FXML
    private Button btnLogout;
    
    @FXML
    private Button btnProperty;
    

    
    public void info(String name){
        lbWelcome.setText("Welcome '"+name+"' Login Successful!!");
        lbName.setText("Mr. "+name);
        lbEmail.setText(name+"@outlook.com");
       
     //   initialize(); 
    }

    
    
    
     @FXML
    void logout (ActionEvent e) {
          Stage stage = (Stage) btnProperty.getScene().getWindow();
          stage.close();
          switchToLogin();
    
    }
    
     @FXML
    void propertyPurchase (ActionEvent e) {
          Stage stage = (Stage) btnLogout.getScene().getWindow();
          stage.close();
          switchToProperty();
    
    }
    
    
    
    
    void switchToLogin(){
    try {  
                FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("login");
                stage.setScene(new Scene(root, 700, 400));
                stage.setResizable(false);
                stage.show();
            } 
    catch (IOException ex) {

                ex.printStackTrace();

          }
            
    }
       
     void switchToProperty(){
    try {  
                FXMLLoader loader = new FXMLLoader(getClass().getResource("Property.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("properfty location");
                stage.setScene(new Scene(root, 700, 400));
                stage.setResizable(false);
                stage.show();
            } 
    catch (IOException ex) {

                ex.printStackTrace();

          }
            
    }
     

 @FXML
    private ListView<Project> ProjectListView; 
    
     
 public void initialize() {
        // Initialize the project and contractors
        
        if(PropertyController.location  == null ){
             lbNodata.setText("No Project Data Found. First Go to Property Purchase");
        } 
        else{
            
        lbNodata.setText("New Data Record Found. Current Running Project");
       // PropertyController propertycontroller= new PropertyController();
       
            for (int i = 0; i <PropertyController.projectsArrayList.size(); i++) {
                
                Project project=(PropertyController.projectsArrayList.get(i));
                
              ProjectListView.getItems().add(project); 
            }
 
        
       ProjectListView.setCellFactory(listView -> { 
           ListCell<Project> cell = new ProjectCellRenderer();
           
           cell.itemProperty();
           
           cell.setOnMouseClicked(event -> {
                if (event.getClickCount() == 2 && cell.getItem() != null) {
            // switch to project details
                   Stage stage = (Stage) btnProperty.getScene().getWindow();
                   stage.close();
                  
                    try {  
                FXMLLoader loader = new FXMLLoader(getClass().getResource("project.fxml"));
                Parent root = loader.load();
                
                ProjectController projectcontroller= loader.getController();
                projectcontroller.infoTake(cell.getItem().getLocation(),cell.getItem().getSize(),
                        cell.getItem().getDetails(),cell.getItem().getCompliance());
               // projectcontroller.infoTake();
                Stage stage1 = new Stage();
                stage1.setTitle("project details");
                stage1.setScene(new Scene(root, 700, 400));
                stage1.setResizable(false);
                stage1.show();
          
            } 
    catch (IOException ex) {

                ex.printStackTrace();

          }
                   
                   
                 
                }
            });
                   
           return cell;
       
       
       });
     
    }
} 
}
