
import javafx.scene.control.ListCell;


public class ProjectCellRenderer extends ListCell<Project>  {
    @Override
    protected void updateItem(Project project, boolean empty) {
        super.updateItem(project, empty);
        if (empty || project == null) {
            setText(null);
        } else {
            setText(project.toString());
        }
    }
}
