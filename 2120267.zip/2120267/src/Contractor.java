
public class Contractor {
    private String fullName;
    private String address;
    private Project project;

    public Contractor(String fullName,String address , Project project) {
        this.address = address;
        this.fullName = fullName;
        this.project = project;
    }

    // Getters and setters

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    @Override
    public String toString() {
        return "Name: " + fullName + " , Address: " + address ;
    }
    
}